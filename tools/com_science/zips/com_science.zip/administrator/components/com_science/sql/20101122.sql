INSERT INTO `jos_sci_project_action_types` (`id`, `description`, `short_description`, `order`) VALUES
(3, 'Demo data', 'Demo data', 3);
