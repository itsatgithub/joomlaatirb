ALTER TABLE `jos_sci_publications` ADD `phd_selected_publication` TINYINT NOT NULL ,
ADD `irb_selected_publication` TINYINT NOT NULL 
