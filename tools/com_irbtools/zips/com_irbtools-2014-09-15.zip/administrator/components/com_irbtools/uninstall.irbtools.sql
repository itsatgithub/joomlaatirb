DROP TABLE `jos_irbtools_users`;
DROP TABLE `jos_irbtools_apps`;
DROP TABLE `jos_irbtools_user_app`;
