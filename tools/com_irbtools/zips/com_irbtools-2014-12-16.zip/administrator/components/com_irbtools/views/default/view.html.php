<?php
/**
 * Joomla! 1.5 component irbtools
 *
 * @version $Id: view.html.php 2010-10-13 07:12:40 svn $
 * @author IRB Barcelona
 * @package Joomla
 * @subpackage irbtools
 * @license GNU/GPL
 *
 * IRB Barcelona Tools
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Import Joomla! libraries
jimport( 'joomla.application.component.view');
class IrbtoolsViewDefault extends JView {
    function display($tpl = null) {
        parent::display($tpl);
    }
}
?>