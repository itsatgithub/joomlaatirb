<?php
/**
 * Joomla! 1.5 component irbtools
 *
 * @version $Id: router.php 2010-10-13 07:12:40 svn $
 * @author IRB Barcelona
 * @package Joomla
 * @subpackage irbtools
 * @license GNU/GPL
 *
 * IRB Barcelona Tools
 *
 * This component file was created using the Joomla Component Creator by Not Web Design
 * http://www.notwebdesign.com/joomla_component_creator/
 *
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/*
 * Function to convert a system URL to a SEF URL
 */
function IrbtoolsBuildRoute(&$query) {

}
/*
 * Function to convert a SEF URL back to a system URL
 */
function IrbtoolsParseRoute($segments) {

}
?>