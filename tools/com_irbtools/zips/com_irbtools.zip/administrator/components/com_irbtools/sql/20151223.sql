ALTER TABLE `jos_irbtools_roaming_users` ADD `email` VARCHAR( 100 ) NOT NULL ;
ALTER TABLE `jos_irbtools_roamings` ADD `email` VARCHAR( 100 ) NOT NULL ;

