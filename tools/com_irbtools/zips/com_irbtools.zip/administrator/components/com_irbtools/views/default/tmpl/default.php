<?php
defined('_JEXEC') or die('Restricted access');
JToolBarHelper::title(JText::_('irbtools'), 'generic.png');
JToolBarHelper::preferences('com_irbtools');
//JToolBarHelper::help( 'screen.irbtools' );
?>
<!-- Deafult administrator message -->
This is the default administrator view of your component. To edit it please edit the file:<br />
/administrator/components/com_irbtools/views/default/tmpl/default.php